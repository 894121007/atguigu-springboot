/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.shiro.samples;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.LockedAccountException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.subject.support.DelegatingSubject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;
import java.beans.Transient;


@Controller
public class LoginController {

    private static final transient Logger log = LoggerFactory.getLogger(LoginController.class);

//    @Autowired
//    private ILoginService loginService;

    //退出的时候是get请求，主要是用于退出
    @RequestMapping(value = "/login",method = RequestMethod.GET)
    public String loginPage(){
        return "/login";
    }

	@RequestMapping(value = "/shiro/login",method = RequestMethod.POST)
    public String login(@RequestParam String username,
                        @RequestParam String password) {
        UsernamePasswordToken token = new UsernamePasswordToken(username, password);
        Subject currentUser = SecurityUtils.getSubject();
        try {
            token.setRememberMe(true); //记住我这行代码放到登录之前，不然记住我是无效的。
            currentUser.login(token);
//            currentUser.hasRole()
            return "/list";
        } catch (UnknownAccountException uae) {
            log.info("There is no user with username of " + token.getPrincipal());
        } catch (IncorrectCredentialsException ice) {
            log.info("Password for account " + token.getPrincipal() + " was incorrect!");
        } catch (LockedAccountException lae) {
            log.info("The account for username " + token.getPrincipal() + " is locked.  " +
                    "Please contact your administrator to unlock it.");
        }
        return "/error";

    }

    @RequestMapping(value = "/list",method = RequestMethod.GET)
    public String list(){
        return "/list";
    }

//    @RequestMapping(value = "/error")
//    public String error(){
//        return "/error.html";
//    }

    //错误页面展示
    @RequestMapping(value = "/unauthorizedUrl",method = RequestMethod.GET)
    public String unauthorizedUrl(){
        return "/unauthorizedUrl";
    }

    //授权判断 admin页面
    @RequestMapping(value = "/admin",method = RequestMethod.GET)
    public String adminPage(){
        return "/roles/admin";
    }

    //授权判断 admin页面
    @RequestMapping(value = "/user",method = RequestMethod.GET)
    public String userPage(){
        return "/roles/user";
    }

    @RequestMapping("testAnnotation")
	@RequiresRoles(value = {"admin"})
    public String testAnnotation() {
		return "/index";
	}

    //数据初始化
//    @RequestMapping(value = "/addUser")
//    public String addUser(@RequestBody Map<String,Object> map){
//        User user = loginService.addUser(map);
//        return "addUser is ok! \n" + user;
//    }
//
//    //角色初始化
//    @RequestMapping(value = "/addRole")
//    public String addRole(@RequestBody Map<String,Object> map){
//        Role role = loginService.addRole(map);
//        return "addRole is ok! \n" + role;
//    }

}
