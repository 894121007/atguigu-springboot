package org.apache.shiro.samples.config;

import org.apache.shiro.authc.Authenticator;
import org.apache.shiro.authc.credential.AllowAllCredentialsMatcher;
import org.apache.shiro.authc.credential.HashedCredentialsMatcher;
import org.apache.shiro.authc.pam.AllSuccessfulStrategy;
import org.apache.shiro.authc.pam.AtLeastOneSuccessfulStrategy;
import org.apache.shiro.authc.pam.ModularRealmAuthenticator;
import org.apache.shiro.crypto.hash.SimpleHash;
import org.apache.shiro.realm.Realm;
import org.apache.shiro.spring.security.interceptor.AuthorizationAttributeSourceAdvisor;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.util.ByteSource;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.apache.shiro.mgt.SecurityManager;

import java.util.*;

/**
 * @author zhanglong
 * @description: TODO
 * @date 2019/5/15 17:26
 *
 */
@Configuration
public class ShiroConfig {

	//将自己的验证方式加入容器
	@Bean
	public MyShiroRealm myShiroRealm() {
		MyShiroRealm myShiroRealm = new MyShiroRealm();
		//设置密码匹配器
		myShiroRealm.setCredentialsMatcher(hshedCredentialsMatcher("MD5",1024));
		return myShiroRealm;
	}

	//将自己的验证方式加入容器
	@Bean
	public MyShiroRealm2 myShiroRealm2() {
		MyShiroRealm2 myShiroRealm2 = new MyShiroRealm2();
		//设置密码匹配器
		myShiroRealm2.setCredentialsMatcher(hshedCredentialsMatcher("SHA1",1024));
		return myShiroRealm2;
	}

	@Bean
	public SecurityManager securityManager() {
		DefaultWebSecurityManager securityManager = new DefaultWebSecurityManager();
//		securityManager.setRealm(myShiroRealm());
		//设置多个realm的匹配策略。共三种，默认是AtLeastOneSuccessfulStrategy（只要有一个匹配成功，就认证成功）
		securityManager.setAuthenticator(getAuthenticator());

		List<Realm> realms = new ArrayList<>();
		realms.add(myShiroRealm());
		realms.add(myShiroRealm2());
		securityManager.setRealms(realms);

		return securityManager;
	}

	/**
	 * 多个Realm的时候，的匹配策略，共三种匹配策略
	 * @return org.apache.shiro.authc.pam.ModularRealmAuthenticator
	 * @throws
	 * @author zhanglong
	 * @date 2019/5/20 10:07
	 */
	@Bean("authenticator")
	public ModularRealmAuthenticator getAuthenticator() {
		ModularRealmAuthenticator modularRealmAuthenticator = new ModularRealmAuthenticator();
		//设置多realm
		modularRealmAuthenticator.setAuthenticationStrategy(new AllSuccessfulStrategy());
		return modularRealmAuthenticator;
	}

	//Filter工厂，设置对应的过滤条件和跳转条件
	@Bean
	public ShiroFilterFactoryBean shiroFilterFactoryBean(SecurityManager securityManager) {
		ShiroFilterFactoryBean shiroFilterFactoryBean = new ShiroFilterFactoryBean();
		shiroFilterFactoryBean.setSecurityManager(securityManager);
		Map<String,String> map = new HashMap<String, String>();

		map.put("/shiro/login","anon");
		//登出
		map.put("/shiro/logout","logout");
		//对所有用户认证
		map.put("/**","authc");
		//登录
		shiroFilterFactoryBean.setLoginUrl("/login");
		//首页
		shiroFilterFactoryBean.setSuccessUrl("/index");
		//错误页面，认证不通过跳转
		shiroFilterFactoryBean.setUnauthorizedUrl("/error");
		shiroFilterFactoryBean.setFilterChainDefinitionMap(map);
		return shiroFilterFactoryBean;
	}

	//加入注解的使用，不加入这个注解不生效
	@Bean
	public AuthorizationAttributeSourceAdvisor authorizationAttributeSourceAdvisor(SecurityManager securityManager) {
		AuthorizationAttributeSourceAdvisor authorizationAttributeSourceAdvisor = new AuthorizationAttributeSourceAdvisor();
		authorizationAttributeSourceAdvisor.setSecurityManager(securityManager);
		return authorizationAttributeSourceAdvisor;
	}

	/**
	 * 密码匹配器
	 * @param
	 * @return org.apache.shiro.authc.credential.HashedCredentialsMatcher
	 * @throws
	 * @author zhanglong
	 * @date 2019/5/20 9:57
	 */
	public HashedCredentialsMatcher hshedCredentialsMatcher(String hshAlgorithmName,int hashIterations) {
		HashedCredentialsMatcher hashedCredentialsMatcher = new HashedCredentialsMatcher();
		//设置加密算法
		hashedCredentialsMatcher.setHashAlgorithmName(hshAlgorithmName);
		//设置重复加密的次数，默认1，可以多次，更安全
		hashedCredentialsMatcher.setHashIterations(hashIterations);
		return hashedCredentialsMatcher;
	}
}
